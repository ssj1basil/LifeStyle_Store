
-- --------------------------------------------------------

--
-- Table structure for table `Supplier`
--

CREATE TABLE `Supplier` (
  `address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Supplier`
--

INSERT INTO `Supplier` (`address`, `city`, `contact`, `email`, `supplier_id`, `name`, `password`) VALUES
('adsasd', 'dsa', 'daslmkasd', 'asdmkjosdaij@hamasd', 1, 'dsakjsdaij', 'f9f320a5f7fe1e49c1082c16dac27f29'),
('fsdkdsof', 'fsdkjifds', 'kjsdf', 'adskp@kokdsk', 2, 'dsakmas', '733540828109ecc5c86ff7fb515e6c4c'),
('jsdof', 'jfdis', 'jdsifsd', 'sdamojas@nkdn', 3, 'dsffds', '3146b6cf39793c85726e3f872476ce05'),
('fsdkjifds', 'fdsijiidfs', 'sdfkjsd', 'dasij@hudsfh', 4, 'adsjijdsa', 'fb60a5e572c0aeca7aca8a514ff84782'),
('kmnmknm', 'kokok', 'nsdknf', 'canon@supplier.net', 5, 'basil', 'e10adc3949ba59abbe56e057f20f883e');
