
-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `Quantity` int(11) NOT NULL DEFAULT '10',
  `Supplier_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `name`, `price`, `Quantity`, `Supplier_id`) VALUES
(1, 'Canon EOS', 36000, 6, 3),
(2, 'Nikon DSLR', 40000, 12, 3),
(3, 'Sony DSLR', 45000, 0, 3),
(4, 'Olympus DSLR', 50000, 5, 4),
(5, 'Titan Model #301', 13000, 25, 5),
(6, 'Titan Model #201', 3000, 15, 5),
(7, 'HMT Milan', 8000, 2, NULL),
(8, 'Faber Luba #111', 18000, 4, NULL),
(9, 'H&W', 800, 19, NULL),
(10, 'Luis Phil', 1000, 10, NULL),
(11, 'John Zok', 1500, 11, NULL),
(12, 'Jhalsani', 1300, 12, NULL);
