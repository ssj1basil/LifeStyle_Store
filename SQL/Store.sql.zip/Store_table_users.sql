
-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `contact`, `city`, `address`) VALUES
(1, 'Mushrif', '12345@email.com', '827ccb0eea8a706c4c34a16891f84e7b', '1234557', 'Calicut', '12345678'),
(2, 'basil', '1234567@jdjask.com', 'fcea920f7412b5da7be0cf42b8c93759', '34567', '', ''),
(3, 'kkdnaksn', 'msmms@fmail.com', '86b6e9bcc2c73cfb5c77d3effbf6de67', 'dusfhhf', '312321', 'ewdsasd'),
(4, 'dsadsa', 'kokjij@jifdjs.com', 'c91c03ea6c46a86cbc019be3d71d0a1a', 'dasdsa', 'fddfs', 'sfdfds'),
(5, 'sadkkjisa', 'sadijas@das.com', '25d5b83da5f823aa5e75ab0fb77a6df6', '32kjidsa', 'dsa,ml', 'adsdsa'),
(6, 'dasijiojawd', 'kjsdfj@jigjm.com', '70b6d00156b7f4a0cdd0ec1d8f37ced4', 'drfghjadsk', 'daskijioas', 'dasmkj'),
(7, 'adsdsafd', 'km@sdinf', '0a1df36468388d322d3e510e9fe66e89', 'dfsdfs', 'fsdfds', 'sfdfsd'),
(8, 'fdkojoihfds', 'moka@idea-mail.net', '912cc49287265c977915277dc081f38d', 'dsffds', 'fdsfds', 'fdsfdsfd'),
(10, 'sdakjkisad', 'dkas@ijfusd', '377100efd0c46324489199f50349e615', 'fdsfds', 'fsdfds', 'fsdfsd'),
(11, 'dsakmjiadsk', 'adsuuj@gmsoc.om', 'ff0314521374ad175a70e8350d04d832', 'dassdadsa', 'asdsa', 'sdasda'),
(12, 'nkn', 'mm@mlmdfs', '8e55c4ed13655edc2d87f92ef23a2599', 'fsfdsfds', 'fddsfsfd', 'dsfsfdfds'),
(13, 'sdjbadsd', 'dsfds@mkvx', 'fab66d5ddd9ede50ace1ae215ec5d792', 'dsfdfsfds', 'sfddfs', 'sdffds'),
(14, 'Mushrif', 'mushrif@gmail.com', 'd41d8cd98f00b204e9800998ecf8427e', 'oiqweqweq', 'Your house', 'Same as your'),
(15, 'dnjanjas', 'asjd@jiefsjdin', '6983d1d1ce61583398420a2474c0523f', 'fsddsf', 'sfsdfs', 'fdssfdfsd'),
(16, 'basil', 'basil@consumer', '827ccb0eea8a706c4c34a16891f84e7b', 'sadknj', 'asdjj', 'dsakjidas');
